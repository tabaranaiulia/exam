import React, { Component } from 'react';
import DeviceList from './components/DeviceList';

class App extends Component {
  render() {
   return (
    <div>
      <DeviceList />
    </div>
    );
  }
}

export default App;
