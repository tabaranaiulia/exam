import React from 'react';

class DeviceList extends React.Component {
    constructor(){
        super();
        this.state = {
            devices: []
        };
    }   
    
  
    render(){
        return (
            <div>

            </div>
        )
    }
}

export default DeviceList;