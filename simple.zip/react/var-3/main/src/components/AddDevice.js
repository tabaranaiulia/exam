import React from 'react';

class AddDevice extends React.Component {
    
    render() {
        return (
            <div>

            </div>
        )
    }
}

export default AddDevice;