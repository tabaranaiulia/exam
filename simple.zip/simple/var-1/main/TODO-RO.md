# Subiect 1 (2.5 pts)
# Tematica: Clienți și servere simple

# Dat fiind serverul `server.js` și fișierul `index.html` din directorul `public` directory:

# Satisfaceți următoarele cerințe:
- fișierul `index.html`, care conține textul `A simple app` este livrat de server ca conținut static (0.5 pts);
- butonul cu id-ul `reload` există în pagină și se poate da click pe el(0.5 pts);
- când se dă click pe butonul cu id-ul `reload` nimic in filtru, toate elementele sunt returnate (0.5 pts);
- când se dă click pe butonul cu id-ul `reload` cu valoarea `red` in filtru, elementele roșii sunt returnate (0.5 pts);
- când se dă click pe butonul cu id-ul `reload` cu o valoare in filtru care nu corespunde culorii niciunui element, este returnată o listă vidă (0.5 pts);