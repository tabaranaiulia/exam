# Subject 1 (2.5 pts)
# TOPIC: Basic servers and clients

# Given the server `server.js` and the file `index.html` in the `public` directory:

# Complete the following tasks:
- the file `index.html`, which contains the text `A simple app` should be delivered from the server as static content (0.5 pts);
- a button with the id `reload` exists in the page and can be clicked (0.5 pts);
- when the button with the id `reload` is clicked with nothing in the filter, all elements are returned(0.5 pts);
- when the button with the id `reload` is clicked with `red` in the filter, elements with color `red` are returned(0.5 pts);
- when the button with the id `reload` is clicked with  a filter color which does not match anything an empty list is returned(0.5 pts); (0.5 pts);

