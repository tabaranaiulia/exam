# Instructions

# Objective : Modify the marked place in the `app.js` file in order to satisfy the tests

# Steps to run the test
1. Change directory to `main` by running `cd main`
2. Install the dependencies by running `npm i`
3. Run the tests by running `npm test`